﻿namespace ProjectUTS_A_160419083_160419107
{
    partial class FormDema
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBoxStaff = new System.Windows.Forms.GroupBox();
            this.pictureBoxStaff = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBoxNasabah = new System.Windows.Forms.GroupBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.buttonExit = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonLoginStaff = new System.Windows.Forms.Button();
            this.buttonLoginNasabah = new System.Windows.Forms.Button();
            this.groupBoxStaff.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStaff)).BeginInit();
            this.groupBoxNasabah.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Zilla Slab", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.label1.Location = new System.Drawing.Point(179, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 42);
            this.label1.TabIndex = 0;
            this.label1.Text = "DEMA";
            // 
            // groupBoxStaff
            // 
            this.groupBoxStaff.Controls.Add(this.buttonLoginStaff);
            this.groupBoxStaff.Controls.Add(this.pictureBoxStaff);
            this.groupBoxStaff.Controls.Add(this.textBox1);
            this.groupBoxStaff.Controls.Add(this.label5);
            this.groupBoxStaff.Controls.Add(this.label3);
            this.groupBoxStaff.Location = new System.Drawing.Point(11, 60);
            this.groupBoxStaff.Name = "groupBoxStaff";
            this.groupBoxStaff.Size = new System.Drawing.Size(219, 289);
            this.groupBoxStaff.TabIndex = 1;
            this.groupBoxStaff.TabStop = false;
            // 
            // pictureBoxStaff
            // 
            this.pictureBoxStaff.Image = global::ProjectUTS_A_160419083_160419107.Properties.Resources.pegawai;
            this.pictureBoxStaff.Location = new System.Drawing.Point(56, 38);
            this.pictureBoxStaff.Name = "pictureBoxStaff";
            this.pictureBoxStaff.Size = new System.Drawing.Size(100, 80);
            this.pictureBoxStaff.TabIndex = 3;
            this.pictureBoxStaff.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Zilla Slab", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(56, 160);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 23);
            this.textBox1.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Zilla Slab", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.label5.Location = new System.Drawing.Point(79, 142);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 15);
            this.label5.TabIndex = 1;
            this.label5.Text = "USER ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Zilla Slab", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.label3.Location = new System.Drawing.Point(78, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 19);
            this.label3.TabIndex = 0;
            this.label3.Text = "STAFF";
            // 
            // groupBoxNasabah
            // 
            this.groupBoxNasabah.Controls.Add(this.buttonLoginNasabah);
            this.groupBoxNasabah.Controls.Add(this.textBox3);
            this.groupBoxNasabah.Controls.Add(this.label7);
            this.groupBoxNasabah.Controls.Add(this.textBox2);
            this.groupBoxNasabah.Controls.Add(this.label6);
            this.groupBoxNasabah.Controls.Add(this.label4);
            this.groupBoxNasabah.Location = new System.Drawing.Point(236, 60);
            this.groupBoxNasabah.Name = "groupBoxNasabah";
            this.groupBoxNasabah.Size = new System.Drawing.Size(219, 289);
            this.groupBoxNasabah.TabIndex = 2;
            this.groupBoxNasabah.TabStop = false;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Zilla Slab", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(58, 211);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 23);
            this.textBox3.TabIndex = 6;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Zilla Slab", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.label7.Location = new System.Drawing.Point(93, 194);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(28, 15);
            this.label7.TabIndex = 5;
            this.label7.Text = "PIN";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Zilla Slab", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(58, 160);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 23);
            this.textBox2.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Zilla Slab", 9.749999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.label6.Location = new System.Drawing.Point(79, 142);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(55, 15);
            this.label6.TabIndex = 3;
            this.label6.Text = "USER ID";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Zilla Slab", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.label4.Location = new System.Drawing.Point(68, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(85, 19);
            this.label4.TabIndex = 1;
            this.label4.Text = "NASABAH";
            // 
            // buttonExit
            // 
            this.buttonExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.buttonExit.Font = new System.Drawing.Font("Zilla Slab", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExit.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonExit.Location = new System.Drawing.Point(197, 355);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(75, 29);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "EXIT";
            this.buttonExit.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Mistral", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.label2.Location = new System.Drawing.Point(214, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 22);
            this.label2.TabIndex = 4;
            this.label2.Text = "Bank";
            // 
            // buttonLoginStaff
            // 
            this.buttonLoginStaff.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.buttonLoginStaff.Font = new System.Drawing.Font("Zilla Slab", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLoginStaff.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonLoginStaff.Location = new System.Drawing.Point(72, 254);
            this.buttonLoginStaff.Name = "buttonLoginStaff";
            this.buttonLoginStaff.Size = new System.Drawing.Size(75, 29);
            this.buttonLoginStaff.TabIndex = 5;
            this.buttonLoginStaff.Text = "LOGIN";
            this.buttonLoginStaff.UseVisualStyleBackColor = false;
            // 
            // buttonLoginNasabah
            // 
            this.buttonLoginNasabah.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(26)))), ((int)(((byte)(82)))), ((int)(((byte)(118)))));
            this.buttonLoginNasabah.Font = new System.Drawing.Font("Zilla Slab", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLoginNasabah.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonLoginNasabah.Location = new System.Drawing.Point(72, 254);
            this.buttonLoginNasabah.Name = "buttonLoginNasabah";
            this.buttonLoginNasabah.Size = new System.Drawing.Size(75, 29);
            this.buttonLoginNasabah.TabIndex = 6;
            this.buttonLoginNasabah.Text = "LOGIN";
            this.buttonLoginNasabah.UseVisualStyleBackColor = false;
            // 
            // FormDema
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(179)))), ((int)(((byte)(213)))));
            this.ClientSize = new System.Drawing.Size(468, 389);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.groupBoxNasabah);
            this.Controls.Add(this.groupBoxStaff);
            this.Controls.Add(this.label1);
            this.Name = "FormDema";
            this.Text = "Dema Bank";
            this.groupBoxStaff.ResumeLayout(false);
            this.groupBoxStaff.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxStaff)).EndInit();
            this.groupBoxNasabah.ResumeLayout(false);
            this.groupBoxNasabah.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBoxStaff;
        private System.Windows.Forms.GroupBox groupBoxNasabah;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBoxStaff;
        private System.Windows.Forms.Button buttonLoginStaff;
        private System.Windows.Forms.Button buttonLoginNasabah;
    }
}

